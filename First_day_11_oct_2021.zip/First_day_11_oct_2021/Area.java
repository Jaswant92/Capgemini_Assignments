import java.util.*;
class Area 
{
public static void main(String args[])
{
 Scanner sc = new Scanner(System.in);
 System.out.println("Enter first Point:");
float x1= sc.nextFloat();
float y1= sc.nextFloat();
 System.out.println("Enter Second Point:");
float x2= sc.nextFloat();
float y2= sc.nextFloat();
 System.out.println("Enter third Point:");
float x3= sc.nextFloat();
float y3= sc.nextFloat();
 
 float area = (x1*(y2-y3)+x2*(y3-y1)+x3*(y1-y2))/2.0f;
 System.out.println("Area of the Triangle is:" + Math.abs(area));
}
}
