import java.util.*;
class Case_Changer
{
  static void Uppercase(String st)
  {
   int l = st.length();
   String st1="";
   char c,d;
   for(int i=0;i<l;i++)
   {
    if(st.charAt(i)>='a' && st.charAt(i)<='z')
    {
     d=st.charAt(i);
     c=Character.toUpperCase(d);
     st1=st1+c;
    }
    else if(st.charAt(i)==(char) ' ' || st.charAt(i)==(char) '.')
    {
     st1=st1+st.charAt(i);
    }
    else
    {
     st1=st1+st.charAt(i);
    }
    
   }
   System.out.println("Upper Case:" +"\n"+ st1);
           System.out.println();
  }
  
  
  static void Lowercase(String str)
  {
  
   int m = str.length();
   String st2="";
   char c1,d1;
   for(int i=0;i<m;i++)
   {
    if(str.charAt(i)>='A' && str.charAt(i)<='Z')
    {
     d1=str.charAt(i);
     c1=Character.toLowerCase(d1);
     st2=st2+c1;
    }
    else if(str.charAt(i)==(char) ' ' || str.charAt(i)==(char) '.')
    {
     st2=st2+str.charAt(i);
    }
    else
    {
     st2=st2+str.charAt(i);
    }
    
   }
   System.out.println("Lower Case:"+"\n" + st2);
           System.out.println();
  }
    
  
  static void Capitalizecase(String str1)
  {
    String words[]=str1.split("\\s");  
    String Word="";  
    for(String w:words){  
        String f1=w.substring(0,1);
        String f2=w.substring(1);  
        Word+=f1.toUpperCase()+f2+" ";  
    }  
    System.out.println("Capitalize: "+"\n"+ Word.trim());  
            System.out.println();
}  
  
  
  static void Sentencecase(String str2)
  {
    char[] arr = str2.toCharArray();

         

        for (int i = 0; i<arr.length; i++)
        {
          arr[0] = Character.toUpperCase(arr[0]);
          if(arr[i] == '.' && i < ((arr.length)-2))
          {
           arr[i+2] = Character.toUpperCase(arr[i+2]);
           
          }
        }

        String s1 = new String(arr);

        System.out.println("Sentence Case:"+"\n" + s1);
        System.out.println();
    
}  
    
  static void Invertcase(String str3)
  {
   int t = str3.length();
   //System.out.println(l);
   String st3="";
   char c2,d2;
   for(int i=0;i<t;i++)
   {
    if(str3.charAt(i)>='A' && str3.charAt(i)<='Z')
    {
     d2=str3.charAt(i);
     c2=Character.toLowerCase(d2);
     st3=st3+c2;
     //System.out.println(st1 +"" + d);
    }
    else if(str3.charAt(i)==(char) ' ' || str3.charAt(i)==(char) '.')
    {
     st3=st3+str3.charAt(i);
    }
    else if(str3.charAt(i)>='a' && str3.charAt(i)<='z')
    {
     d2=str3.charAt(i);
     c2=Character.toUpperCase(d2);
     st3=st3+c2;
     //System.out.println(st1 +"" + d);
    }
    
   }
   System.out.println("Invert:"+"\n" + st3);
  }
  
  public static void main(String args[])
  {
   System.out.print("Enter the input String:");
   Scanner sc = new Scanner(System.in);
   String s = sc.nextLine();
   Uppercase(s);
   Lowercase(s);
   Capitalizecase(s);
   Sentencecase(s);
   Invertcase(s);
  
  }
}
