import java.util.*;
class Factorial
{
 static int calculate_fact(int y)
 {
  if(y==0)
   {
    return 1;
    }
    else 
    {
     return (y *calculate_fact(y-1));
    }
 }
 
 public static void main(String args[])
 {
  System.out.print("Enter the number:");
  Scanner sc = new Scanner(System.in);
  int n= sc.nextInt();
  int fact = calculate_fact(n);
  System.out.println();
  System.out.println("Factorial of the number is:"+ fact);
 }
}
