import java.util.*;
class Money
{
 static void Manage_Money(float amt)
 {
   float NEC= (float) 0.55 * amt; 
   float FFA= (float) 0.1 * amt; 
   float EDU = (float)  0.1 *amt; 
   float LTSS= (float) 0.1 *amt; 
   float PLAY= (float) 0.1 * amt; 
   float GIVE= (float) 0.05 * amt; 
   System.out.print("NEC:"+ ""+NEC);
   System.out.print("          ");
   System.out.println("LTSS:"+ ""+LTSS);
   System.out.print("FFA:"+ ""+FFA);
   System.out.print("          ");
   System.out.println("PLAY:"+ ""+PLAY);
   System.out.print("EDU:"+ ""+EDU);
   System.out.print("          ");
   System.out.println("GIVE:"+ ""+GIVE);
 }
 public static void main(String args[])
 {
  System.out.print("Enter your Income this month :");
  Scanner in = new Scanner(System.in);
  float mon = in.nextFloat();
  Manage_Money(mon);
 
 }

}
