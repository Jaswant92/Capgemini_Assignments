import java.util.*;
class Fibonacci
{

 public static void main(String args[])
 {
   System.out.print("Enter the number:");
   Scanner sc = new Scanner(System.in);
   int n= sc.nextInt();
   int x=0;
   int y=1;
   int sum;
   sum= x+y;
   System.out.print(sum+ " ");
   while(sum<= n)
   {
    System.out.print(sum+ " ");
    x=y;
    y=sum;
    sum= x+y;
    
   }
   
 }
}
